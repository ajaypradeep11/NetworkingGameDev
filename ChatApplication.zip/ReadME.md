## Application Name : Networking Project 1 (Chat Application)
#### Execute in Debug X64 mode
#### TEAM MEMBERS (PRADEEP MUTHAMIL SELVAM)
#### TEAM MEMBERS (DENNISON DAVID)
---
#### Note:
-  Backspace is not working correctly
-  Used map of String, Socket vectors
-  Checked and implemented Few conditions like (Left the room and joined the room)
